function ingresar(){
    let nombre,edad,estado, institucion;
    nombre=document.getElementById("nom").valvue;
    edad=document.getElementById("ed").valvue;
    institucion=document.getElementById("ins").valvue;
    //
    if (document.getElementById("radio1").checked){
        estado="Sin nivel de estudios";
    }
    else if (document.getElementById("radio2").checked){
        estado="Primaria";
    }else if (document.getElementById("radio3").checked){
        estado="Secundaria";
    }else if (document.getElementById("radio4").checked){
        estado="Técnico";
    }else if (document.getElementById("radio5").checked){
        estado="Universitaria";
    }else if (document.getElementById("radio3").checked){
        estado="Otro tipo de estudio";
    }
    alert("El estudiante:"+nombre+" "+"con edad de;"+edad+"años,"+"\n"+"Nivel de Estudios:"+estado+"\n"+"Graduado en la institucion:"+institucion);
}